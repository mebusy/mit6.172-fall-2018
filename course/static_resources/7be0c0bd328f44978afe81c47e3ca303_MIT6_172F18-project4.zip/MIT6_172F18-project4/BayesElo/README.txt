bayeselo
by Rémi Coulom
http://remi.coulom.free.fr/Bayesian-Elo/

To compile, "cd" into the BayesElo directory and "make".

This software is protected under the terms of the GNU GPL
See http://www.gnu.org/copyleft/gpl.html
