#include <csi.h>

void __csi_init() {
  // TODO: Fill this in.
}

void __csi_unit_init(const char * const file_name,
                     const instrumentation_counts_t counts) {
  // TODO: Fill this in.
}

// TODO: Fill in the appropriate hooks (see API reference at the end
// of the handout).
