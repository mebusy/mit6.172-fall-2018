#include <csi.h>

// This tool reports the number of times each function in the program
// was executed.

// TODO: Add global variables for tracking function coverage.

// TODO: Add a report function.

void __csi_init() {
  // TODO: Register the report function to run at exit.
}

void __csi_unit_init(const char * const file_name,
                     const instrumentation_counts_t counts) {
  // Expand any data structures to accommodate the additional functions
  // in this compilation unit.

  // TODO: Fill this in.
}

// TODO: Fill in the appropriate hooks (see API reference at the end
// of the handout).
